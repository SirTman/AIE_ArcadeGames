#pragma once
#include <iostream>
class Fighter
{
private:
	/*//Stats
	std::string m_name = "";
	int m_health = 0;
	int m_AttackPow = 0;
	
	//Alive and Team
	bool m_Foe = false;
	bool m_Alive = true;*/
	
public:
	Fighter();

	~Fighter();
};

