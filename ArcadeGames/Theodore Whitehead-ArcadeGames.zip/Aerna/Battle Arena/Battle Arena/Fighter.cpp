#include "Fighter.h"
#include <cstdlib>
#include <time.h>
#include <iostream>

Fighter::Fighter() 
{
	/*//Intialise
	Fighter::setHealth(int NUM1)
	{
		m_health = NUM1;
	}
	Fighter setAttack(int NUM2)
	{
		m_AttackPow = NUM2;
	}

	//Fighting Core
	int DamgeCal(int DMG)
	{
		m_health -= DMG;
		return m_health;
	}*/
}

Fighter::~Fighter() {}
