#include "Entity.h"



Entity::Entity()
{
}


Entity::~Entity()
{
}

int Entity::attack()
{
	return 10;
}

void Entity::takeDamage(int damage)
{

}

bool Entity::isAlive()
{
	return health = 0;
}
